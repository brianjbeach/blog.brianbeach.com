﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.UserCode;

namespace BrianBeach.FullTrustProxy.Diagnostics
{
    class EventLogProxy : SPProxyOperation
    {
        public override object Execute(SPProxyOperationArgs args)
        {
            string source = ((EventLogProxyArgs)args).Source;
            string message = ((EventLogProxyArgs)args).Message;
            System.Diagnostics.EventLog.WriteEntry(source, message);
            return null;
        }
    }
}
