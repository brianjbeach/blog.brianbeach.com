﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.UserCode;

namespace BrianBeach.FullTrustProxy.Diagnostics
{
    [Serializable]
    class EventLogProxyArgs : SPProxyOperationArgs
    {
        private string source;
        private string message;

        public string Source
        {
            get { return source; }
            set { source = value; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }
    }
}
