using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.UserCode;
using Microsoft.SharePoint.Administration;

namespace BrianBeach.FullTrustProxy.Diagnostics.Features.Feature1
{

    [Guid("2f2d1b78-c30b-4197-ba44-06052b97448c")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPUserCodeService service = SPUserCodeService.Local;
            string assembly = "BrianBeach.FullTrustProxy.Diagnostics, Version=1.0.0.0, Culture=neutral, PublicKeyToken=e6c3143148ad819b";
            string type = "BrianBeach.FullTrustProxy.Diagnostics.EventLogProxy";
            SPProxyOperationType operation = new SPProxyOperationType(assembly, type);
            service.ProxyOperationTypes.Add(operation);
            service.Update();
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPUserCodeService service = SPUserCodeService.Local;
            string assembly = "BrianBeach.FullTrustProxy.Diagnostics, Version=1.0.0.0, Culture=neutral, PublicKeyToken=e6c3143148ad819b";
            string type = "BrianBeach.FullTrustProxy.Diagnostics.EventLogProxy";
            SPProxyOperationType operation = new SPProxyOperationType(assembly, type);
            service.ProxyOperationTypes.Remove(operation);
            service.Update();
        }
    }
}
