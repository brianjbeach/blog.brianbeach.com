﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;

[assembly: System.Security.AllowPartiallyTrustedCallersAttribute()]
namespace BrianBeach.FullTrustProxy.Diagnostics
{
    public class EventLog
    {
        public static void WriteEntry(string Source, string Message)
        {
            string assembly = "BrianBeach.FullTrustProxy.Diagnostics, Version=1.0.0.0, Culture=neutral, PublicKeyToken=e6c3143148ad819b";
            string type = "BrianBeach.FullTrustProxy.Diagnostics.EventLogProxy";
            EventLogProxyArgs args = new EventLogProxyArgs();
            args.Source = Source;
            args.Message = Message;
            SPUtility.ExecuteRegisteredProxyOperation(assembly, type, args);
        }
    }
}
